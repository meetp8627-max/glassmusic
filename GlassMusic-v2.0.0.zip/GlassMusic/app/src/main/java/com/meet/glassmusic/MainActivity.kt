package com.meet.glassmusic

import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import com.styropyr0.prismal.PrismalGlassSurface
import com.styropyr0.prismal.shapes.PrismalCapsule
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.text.TextStyle
import com.styropyr0.prismal.components.PrismalGlassMenu
import com.styropyr0.prismal.components.PrismalGlassMenuDivider
import com.styropyr0.prismal.components.PrismalGlassMenuItem
import com.styropyr0.prismal.components.PrismalGlassProgressBar
import com.styropyr0.prismal.components.PrismalGlassSlider
import com.styropyr0.prismal.components.PrismalGlassToggle
import com.styropyr0.prismal.components.PrismalHorizontalSelector
import com.styropyr0.prismal.components.PrismalRulerSelector
import com.styropyr0.prismal.components.PrismalSegmentedControl
import com.styropyr0.prismal.components.prismalMenuAnchor
import com.styropyr0.prismal.sources.PrismalGlassLayer
import com.styropyr0.prismal.sources.prismalGlassLayer
import com.styropyr0.prismal.sources.rememberPrismalGlassLayer
import com.kyant.backdrop.backdrops.LayerBackdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop

val Accent = Color(0xFFFA2D48)
val LocalOpenArtist = staticCompositionLocalOf<(String) -> Unit> { {} }
val LocalPrismal = staticCompositionLocalOf<PrismalGlassLayer?> { null }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent)) {
                Surface(color = Color.Transparent, contentColor = Color.White) { App() }
            }
        }
    }
}

@Composable
fun App(vm: MusicVM = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    var full by remember { mutableStateOf(false) }
    BackHandler(full) { full = false }
    val backdrop = rememberLayerBackdrop()
    val prismal = rememberPrismalGlassLayer()
    var showSettings by remember { mutableStateOf(false) }
    CompositionLocalProvider(LocalOpenArtist provides { name: String -> full = false; vm.openArtist(name) }, LocalPrismal provides prismal) {
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().layerBackdrop(backdrop)) {
            AmbientBackground(vm, Modifier.fillMaxSize().prismalGlassLayer(prismal))
            when (tab) { 0 -> Home(vm) { showSettings = true }; 1 -> NewScreen(vm); 2 -> RadioScreen(vm); 3 -> Library(vm); else -> SearchScreen(vm) }
            if (vm.artistName != null) ArtistScreen(vm)
            if (showSettings) SettingsScreen(vm) { showSettings = false }
        }
        Column(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            vm.current?.let { MiniPlayer(vm, backdrop) { full = true } }
            TabBar(tab, backdrop) { tab = it }
        }
        AnimatedVisibility(full, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            NowPlaying(vm) { full = false }
        }
        vm.ytVideo?.let { v -> YtPlayer(v) { vm.closeYt() } }
    }
    }
}

@Composable
fun Art(url: String, size: Int, radius: Int = 12) = AsyncImage(
    model = url, contentDescription = null, contentScale = ContentScale.Crop,
    modifier = Modifier.size(size.dp).clip(RoundedCornerShape(radius.dp)).background(Color(0xFF2A2A33))
)

@Composable
fun TrackRow(t: Track, vm: MusicVM, onClick: () -> Unit) {
    val openArtist = LocalOpenArtist.current
    val pb = LocalPrismal.current
    var menu by remember { mutableStateOf(false) }
    var anchor by remember { mutableStateOf(Rect.Zero) }
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Art(t.art, 54)
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(t.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(t.artist, color = Color.White.copy(0.6f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = if (t.id.startsWith("radio:")) Modifier else Modifier.clickable { openArtist(t.artist) })
        }
        IconButton({ menu = true }, Modifier.prismalMenuAnchor { anchor = it }) {
            Icon(Icons.Filled.MoreVert, "More", tint = Color.White.copy(0.6f))
        }
        if (pb != null) PrismalGlassMenu(
            expanded = menu, onDismissRequest = { menu = false }, anchorBounds = anchor, backdrop = pb,
            surfaceColor = Color(0xFF2A2A33).copy(alpha = 0.85f)
        ) {
            PrismalGlassMenuItem("Play next", { vm.playNext(t); menu = false }, textColor = Color.White)
            PrismalGlassMenuItem(if (vm.isLiked(t)) "Remove from Library" else "Add to Library", { vm.like(t); menu = false }, textColor = Color.White)
            if (!t.id.startsWith("radio:")) {
                PrismalGlassMenuDivider()
                PrismalGlassMenuItem("Go to artist", { menu = false; openArtist(t.artist) }, textColor = Color.White)
            }
        }
        IconButton({ vm.like(t) }) {
            Icon(if (vm.isLiked(t)) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, null,
                tint = if (vm.isLiked(t)) Accent else Color.White.copy(0.6f))
        }
    }
}

@Composable
fun YtRow(v: YtVideo, vm: MusicVM, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(v.art, null, contentScale = ContentScale.Crop,
            modifier = Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF2A2A33)))
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(v.title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(v.channel, color = Color.White.copy(0.6f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton({ vm.toggleYt(v) }) {
            Icon(if (vm.isSavedYt(v)) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, null,
                tint = if (vm.isSavedYt(v)) Accent else Color.White.copy(0.6f))
        }
    }
}

@Composable
fun HeroCard(t: Track, onPlay: () -> Unit) {
    Box(Modifier.padding(horizontal = 20.dp).fillMaxWidth().aspectRatio(1f)
        .clip(RoundedCornerShape(28.dp)).background(Color(0xFF2A2A33)).clickable(onClick = onPlay)) {
        AsyncImage(t.art, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(0.75f)))))
        Column(Modifier.align(Alignment.BottomStart).padding(20.dp).fillMaxWidth(0.7f)) {
            Text("FEATURED", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Accent)
            Text(t.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(t.artist, fontSize = 15.sp, color = Color.White.copy(0.7f), maxLines = 1)
        }
        Glass(Modifier.align(Alignment.BottomEnd).padding(18.dp).size(58.dp), CircleShape) {
            Icon(Icons.Filled.PlayArrow, null, Modifier.align(Alignment.Center).size(32.dp))
        }
    }
}

val MixColors = listOf(
    Color(0xFFFA7333) to Color(0xFFBF1A4D), Color(0xFF3380E6) to Color(0xFF6633B3),
    Color(0xFF33BF8C) to Color(0xFF1A5980), Color(0xFFF2BF33) to Color(0xFFE65940))

@Composable
fun SectionTitle(s: String) =
    Text(s, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 20.dp, top = 26.dp, bottom = 12.dp))

@Composable
fun MixCard(name: String, i: Int, onClick: () -> Unit) {
    val (c1, c2) = MixColors[i % MixColors.size]
    Box(Modifier.size(width = 210.dp, height = 140.dp).clip(RoundedCornerShape(22.dp))
        .background(Brush.linearGradient(listOf(c1, c2))).clickable(onClick = onClick)) {
        Text("MADE FOR YOU", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(0.75f),
            modifier = Modifier.padding(16.dp))
        Text(name, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomStart).padding(16.dp))
    }
}

@Composable
fun ChartCard(vm: MusicVM) {
    val top = vm.trending.take(5)
    Column(Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(RoundedCornerShape(26.dp))
        .background(Brush.linearGradient(listOf(Color(0xFFFA2D48), Color(0xFFC2185B)))).padding(18.dp)) {
        Text("Top 5", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Trending this week", fontSize = 13.sp, color = Color.White.copy(0.75f), modifier = Modifier.padding(bottom = 10.dp))
        top.forEachIndexed { i, t ->
            Row(Modifier.fillMaxWidth().clickable { vm.play(vm.trending, i) }.padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}", fontWeight = FontWeight.Bold, modifier = Modifier.width(22.dp))
                Art(t.art, 40, 8)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(t.title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(t.artist, fontSize = 12.sp, color = Color.White.copy(0.75f), maxLines = 1)
                }
                Icon(Icons.Filled.PlayArrow, null, Modifier.size(24.dp))
            }
        }
    }
}

@Composable
fun Home(vm: MusicVM, onSettings: () -> Unit = {}) {
    val pb = LocalPrismal.current
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = 220.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 20.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Home", fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onSettings) { Icon(Icons.Filled.Settings, "Settings", tint = Color.White.copy(0.8f)) }
            }
        }
        vm.error?.let { item { Text(it, color = Accent, fontSize = 13.sp, modifier = Modifier.clickable { vm.load() }.padding(horizontal = 20.dp, vertical = 6.dp)) } }
        if (vm.trending.isEmpty() && vm.error == null) item {
            if (pb != null) PrismalGlassProgressBar(progress = { 0f }, backdrop = pb, indeterminate = true,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp).fillMaxWidth())
        }
        vm.trending.firstOrNull()?.let { t -> item { HeroCard(t) { vm.play(vm.trending, 0) } } }
        if (vm.mixes.isNotEmpty()) {
            item { SectionTitle("Made for You") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    itemsIndexed(vm.mixes) { i, mix -> MixCard(mix.first, i) { vm.play(mix.second, 0) } }
                }
            }
        }
        if (vm.trending.size >= 5) { item { Spacer(Modifier.height(26.dp)); ChartCard(vm) } }
        item { SectionTitle("Trending this week") }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                itemsIndexed(vm.trending.drop(1)) { i, t ->
                    Column(Modifier.width(150.dp).clickable { vm.play(vm.trending, i + 1) }) {
                        Art(t.art, 150, 20)
                        Text(t.title, Modifier.padding(top = 8.dp), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(t.artist, color = Color.White.copy(0.6f), fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
        }
        if (vm.recent.isNotEmpty() && vm.showRecent) {
            item { SectionTitle("Recently Played") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    itemsIndexed(vm.recent.toList()) { i, t ->
                        Column(Modifier.width(130.dp).clickable { vm.play(vm.recent.toList(), i) }) {
                            Art(t.art, 130, 18)
                            Text(t.title, Modifier.padding(top = 8.dp), fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(t.artist, color = Color.White.copy(0.6f), fontSize = 12.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
        item { SectionTitle("Popular this month") }
        itemsIndexed(vm.fresh) { i, t -> TrackRow(t, vm) { vm.play(vm.fresh, i) } }
    }
}

@Composable
fun NewScreen(vm: MusicVM) {
    val rows = vm.trending.chunked(2)
    val pb = LocalPrismal.current
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = 220.dp)) {
        item { Text("New", fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 20.dp, top = 20.dp, bottom = 14.dp)) }
        if (vm.trending.isEmpty()) item {
            if (vm.error != null) Text(vm.error ?: "", color = Accent,
                modifier = Modifier.clickable { vm.load() }.padding(horizontal = 20.dp, vertical = 8.dp))
            else if (pb != null) PrismalGlassProgressBar(progress = { 0f }, backdrop = pb, indeterminate = true,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp).fillMaxWidth())
        }
        item { Text("Top picks", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 20.dp, bottom = 10.dp)) }
        items(rows.size) { r ->
            Row(Modifier.padding(horizontal = 20.dp, vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                rows[r].forEachIndexed { k, t ->
                    Column(Modifier.weight(1f).clickable { vm.play(vm.trending, r * 2 + k) }) {
                        AsyncImage(t.art, null, contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(20.dp)).background(Color(0xFF2A2A33)))
                        Text(t.title, Modifier.padding(top = 8.dp), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(t.artist, color = Color.White.copy(0.6f), fontSize = 13.sp, maxLines = 1)
                    }
                }
                if (rows[r].size == 1) Spacer(Modifier.weight(1f))
            }
        }
        item { Text("Popular this month", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 20.dp, top = 20.dp, bottom = 6.dp)) }
        itemsIndexed(vm.fresh) { i, t -> TrackRow(t, vm) { vm.play(vm.fresh, i) } }
    }
}

@Composable
fun RadioScreen(vm: MusicVM) {
    val pb = LocalPrismal.current
    var q by remember { mutableStateOf("") }
    var sel by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { if (vm.stations.isEmpty()) vm.loadRadio() }
    val chips = listOf("Top" to null, "Hindi" to "hindi", "Bollywood" to "bollywood", "Pop" to "pop", "Lofi" to "lofi", "News" to "news", "Jazz" to "jazz")
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = 220.dp)) {
        item {
            Text("Radio", fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 20.dp, top = 20.dp, bottom = 14.dp))
            GlassSearchField(query = q, onQueryChange = { q = it }, placeholder = "Search live stations",
                onSearch = { vm.loadRadio(name = q) }, onClear = { q = ""; vm.loadRadio(tag = chips[sel].second) })
            Spacer(Modifier.height(12.dp))
        }
        item {
            if (pb != null) PrismalHorizontalSelector(
                labels = chips.map { it.first }, selectedIndex = sel,
                onSelected = { if (it != sel) { sel = it; vm.loadRadio(tag = chips[it].second) } },
                backdrop = pb, textStyle = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold), textColor = Color.White,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
        }
        vm.radioStatus?.let { s ->
            item {
                if (s == "Loading…" && pb != null) PrismalGlassProgressBar(progress = { 0f }, backdrop = pb, indeterminate = true,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp).fillMaxWidth())
                else Text(s, color = Color.White.copy(0.6f), modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp))
            }
        }
        itemsIndexed(vm.stations) { i, s -> TrackRow(s, vm) { vm.play(vm.stations, i) } }
    }
}

@Composable
fun ArtistScreen(vm: MusicVM) {
    val name = vm.artistName ?: return
    BackHandler { vm.closeArtist() }
    val tracks = vm.artistTracks
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF3A1020), Color(0xFF0B0B10), Color(0xFF0B0B10))))) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 220.dp)) {
            item {
                Box(Modifier.fillMaxWidth().height(380.dp)) {
                    tracks.firstOrNull()?.let {
                        AsyncImage(it.art, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    }
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(0.15f), Color(0xFF0B0B10)))))
                    Text(name, fontSize = 36.sp, fontWeight = FontWeight.Bold, maxLines = 2,
                        modifier = Modifier.align(Alignment.BottomStart).padding(20.dp))
                }
            }
            item {
                Row(Modifier.padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Box(Modifier.size(64.dp).clip(CircleShape).background(Accent)
                        .clickable { if (tracks.isNotEmpty()) vm.play(tracks, 0) }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.PlayArrow, null, Modifier.size(36.dp))
                    }
                    Text(if (vm.artistLoading) "Loading…" else "${tracks.size} songs", color = Color.White.copy(0.6f))
                }
            }
            item { SectionTitle("Top Songs") }
            itemsIndexed(tracks) { i, t -> TrackRow(t, vm) { vm.play(tracks, i) } }
        }
        Glass(Modifier.statusBarsPadding().padding(16.dp).size(44.dp).clickable { vm.closeArtist() }, CircleShape) {
            Icon(Icons.Filled.ArrowBackIosNew, "Back", Modifier.align(Alignment.Center).size(18.dp))
        }
    }
}

@Composable
fun SearchScreen(vm: MusicVM) {
    val pb = LocalPrismal.current
    var q by remember { mutableStateOf("") }
    var live by remember { mutableStateOf(false) }
    val genres = listOf("Lofi", "Pop", "Rock", "Electronic", "Jazz", "Classical", "Hip Hop", "Ambient")
    val tiles = listOf(
        Color(0xFFFA7333) to Color(0xFFBF1A4D), Color(0xFF3380E6) to Color(0xFF6633B3),
        Color(0xFF33BF8C) to Color(0xFF1A5980), Color(0xFFF2BF33) to Color(0xFFE65940),
        Color(0xFF994DE6) to Color(0xFFE64D99))
    val doSearch = { if (q.isNotBlank()) { if (YouTube.configured) vm.searchYt(q, live) else vm.searchJamendo(q) } }
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = 220.dp)) {
        item {
            Text("Search", fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 20.dp, top = 20.dp, bottom = 14.dp))
            GlassSearchField(query = q, onQueryChange = { q = it }, placeholder = "Artists, songs, albums",
                onSearch = { doSearch() }, onClear = { q = ""; vm.clearSearch() })
            if (YouTube.configured && pb != null) {
                PrismalSegmentedControl(
                    labels = listOf("Songs", "Live"), selectedIndex = if (live) 1 else 0,
                    onSelected = { live = it == 1; doSearch() }, backdrop = pb, textColor = Color.White,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp).fillMaxWidth()
                )
            } else Spacer(Modifier.height(16.dp))
            vm.searchError?.let { Text(it, color = Accent, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) }
        }
        if (vm.results.isEmpty() && vm.ytResults.isEmpty()) {
            item { Text("Browse categories", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 12.dp)) }
            items(genres.chunked(2).size) { r ->
                Row(Modifier.padding(horizontal = 20.dp, vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    genres.chunked(2)[r].forEachIndexed { k, g ->
                        val (c1, c2) = tiles[(r * 2 + k) % tiles.size]
                        Box(Modifier.weight(1f).aspectRatio(1.6f).clip(RoundedCornerShape(18.dp))
                            .background(Brush.linearGradient(listOf(c1, c2)))
                            .clickable { q = g; vm.searchJamendo(g) }) {
                            Text(g, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomStart).padding(14.dp))
                        }
                    }
                }
            }
        }
        itemsIndexed(vm.results) { i, t -> TrackRow(t, vm) { vm.play(vm.results, i) } }
        itemsIndexed(vm.ytResults) { _, v -> YtRow(v, vm) { vm.playYt(v) } }
    }
}

@Composable
fun Library(vm: MusicVM) {
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = 220.dp)) {
        item { Text("Library", fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp)) }
        if (vm.liked.isEmpty() && vm.savedYt.isEmpty()) item { Text("Tap the heart on a song or video to add it here.", color = Color.White.copy(0.6f), modifier = Modifier.padding(20.dp)) }
        if (vm.liked.isNotEmpty()) item { Text("Songs", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) }
        itemsIndexed(vm.liked.toList()) { i, t -> TrackRow(t, vm) { vm.play(vm.liked.toList(), i) } }
        if (vm.savedYt.isNotEmpty()) item { Text("YouTube", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) }
        itemsIndexed(vm.savedYt.toList()) { _, v -> YtRow(v, vm) { vm.playYt(v) } }
    }
}

@Composable
fun YtPlayer(v: YtVideo, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    Column(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.KeyboardArrowDown, null) }
            Text(v.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        }
        key(v.id) {
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        webChromeClient = WebChromeClient()
                        loadDataWithBaseURL("https://www.youtube.com", ytHtml(v.id), "text/html", "utf-8", null)
                    }
                },
                onRelease = { it.destroy() },
                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
            )
        }
        Text(v.channel, color = Color.White.copy(0.6f), modifier = Modifier.padding(16.dp))
    }
}

fun ytHtml(id: String) = """<html><body style="margin:0;background:#000;height:100%">
<iframe style="position:absolute;top:0;left:0;width:100%;height:100%" src="https://www.youtube.com/embed/$id?autoplay=1&playsinline=1"
frameborder="0" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe></body></html>"""

@Composable
fun MiniPlayer(vm: MusicVM, backdrop: LayerBackdrop, open: () -> Unit) {
    val t = vm.current ?: return
    GlassSurface(backdrop, Modifier.fillMaxWidth().clickable(onClick = open), RoundedCornerShape(26.dp)) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Art(t.art, 46, 14)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(t.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(t.artist, fontSize = 12.sp, color = Color.White.copy(0.6f), maxLines = 1)
            }
            IconButton({ vm.toggle() }) { Icon(if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, Modifier.size(30.dp)) }
            IconButton({ vm.next() }) { Icon(Icons.Filled.SkipNext, null, Modifier.size(30.dp)) }
        }
    }
}

@Composable
fun TabBar(sel: Int, backdrop: LayerBackdrop, onSel: (Int) -> Unit) {
    val items = listOf(Icons.Filled.Home to "Home", Icons.Filled.GridView to "New", Icons.Filled.Radio to "Radio", Icons.Filled.LibraryMusic to "Library", Icons.Filled.Search to "Search")
    LiquidBottomTabs(
        selectedTabIndex = { sel },
        onTabSelected = onSel,
        backdrop = backdrop,
        tabsCount = items.size,
        modifier = Modifier.fillMaxWidth()
    ) {
        items.forEachIndexed { i, (icon, label) ->
            val scale = LocalLiquidBottomTabScale.current
            LiquidBottomTab({ onSel(i) }) {
                Icon(icon, label, tint = Color.White,
                    modifier = Modifier.size(24.dp).graphicsLayer { val s = scale(); scaleX = s; scaleY = s })
                Text(label, fontSize = 10.sp, color = Color.White, maxLines = 1)
            }
        }
    }
}

@Composable
fun NowPlaying(vm: MusicVM, close: () -> Unit) {
    val t = vm.current ?: return
    var showQueue by remember { mutableStateOf(false) }
    val openArtist = LocalOpenArtist.current
    val dur = ((vm.player?.duration ?: 0L).takeIf { it > 0 } ?: (t.durationSec * 1000L)).coerceAtLeast(1)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        val glow = listOf(Color(0xFFFA7333), Color(0xFF3380E6), Color(0xFF33BF8C), Color(0xFFF2BF33), Color(0xFF994DE6))
        val g1 = glow[Math.abs(t.id.hashCode()) % glow.size]
        val g2 = glow[(Math.abs(t.id.hashCode()) + 1) % glow.size]
        val g3 = glow[(Math.abs(t.id.hashCode()) + 4) % glow.size]
        val bd = rememberLayerBackdrop()
        val pbd = rememberPrismalGlassLayer()
        Box(Modifier.fillMaxSize().layerBackdrop(bd).prismalGlassLayer(pbd).background(Color.Black)) {
        Box(Modifier.offset(x = (-90).dp, y = 40.dp).size(420.dp).background(Brush.radialGradient(listOf(g1.copy(alpha = 0.55f), Color.Transparent))))
        Box(Modifier.offset(x = 110.dp, y = 330.dp).size(400.dp).background(Brush.radialGradient(listOf(g2.copy(alpha = 0.5f), Color.Transparent))))
        Box(Modifier.offset(x = (-60).dp, y = 520.dp).size(380.dp).background(Brush.radialGradient(listOf(g3.copy(alpha = 0.45f), Color.Transparent))))
        }
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.padding(top = 12.dp).width(42.dp).height(5.dp).clip(CircleShape)
                .background(Color.White.copy(0.5f)).clickable(onClick = close))
            if (showQueue) {
                Text("Continue Playing", fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 8.dp))
                LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                    itemsIndexed(vm.queue) { i, q ->
                        val now = q.id == t.id
                        Row(Modifier.fillMaxWidth().clickable { vm.playAt(i) }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Art(q.art, 46, 10)
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(q.title, fontWeight = FontWeight.SemiBold, color = if (now) Accent else Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(q.artist, fontSize = 12.sp, color = Color.White.copy(0.6f), maxLines = 1)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            } else {
                Spacer(Modifier.weight(1f))
                AsyncImage(t.art, null, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().aspectRatio(1f).shadow(30.dp, RoundedCornerShape(26.dp)).clip(RoundedCornerShape(26.dp)))
                Spacer(Modifier.height(28.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(t.title, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(t.artist, fontSize = 18.sp, color = Color.White.copy(0.65f), maxLines = 1,
                        modifier = if (t.id.startsWith("radio:")) Modifier else Modifier.clickable { openArtist(t.artist) })
                }
                IconButton({ vm.like(t) }) {
                    Icon(if (vm.isLiked(t)) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, null,
                        tint = if (vm.isLiked(t)) Accent else Color.White)
                }
            }
            if (t.durationSec > 0) {
            PrismalGlassSlider(
                value = { vm.pos.toFloat().coerceIn(0f, dur.toFloat()) },
                onValueChange = { vm.seek(it.toLong()) },
                valueRange = 0f..dur.toFloat(),
                visibilityThreshold = 1f,
                backdrop = pbd,
                modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt(vm.pos), fontSize = 12.sp, color = Color.White.copy(0.6f))
                Text("-" + fmt(dur - vm.pos), fontSize = 12.sp, color = Color.White.copy(0.6f))
            }
            } else {
                Text("● LIVE", color = Accent, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 30.dp))
            }
            Spacer(Modifier.height(16.dp))
            GlassSurface(bd, Modifier.fillMaxWidth(), CircleShape) {
                Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ vm.toggleShuffle() }) { Icon(Icons.Filled.Shuffle, null, tint = if (vm.shuffle) Accent else Color.White) }
                    IconButton({ vm.prev() }) { Icon(Icons.Filled.SkipPrevious, null, Modifier.size(40.dp)) }
                    IconButton({ vm.toggle() }, Modifier.size(68.dp)) { Icon(if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, Modifier.size(54.dp)) }
                    IconButton({ vm.next() }) { Icon(Icons.Filled.SkipNext, null, Modifier.size(40.dp)) }
                    IconButton({ vm.toggleRepeat() }) { Icon(Icons.Filled.Repeat, null, tint = if (vm.repeat) Accent else Color.White) }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End) {
                IconButton({ showQueue = !showQueue }) {
                    Icon(Icons.Filled.QueueMusic, "Queue", tint = if (showQueue) Accent else Color.White)
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
fun Blob(color: Color, size: Dp, x: Dp, y: Dp, animate: Boolean, ms: Int) {
    val shift = if (animate) {
        rememberInfiniteTransition(label = "blob").animateFloat(
            -1f, 1f, infiniteRepeatable(tween(ms, easing = LinearEasing), RepeatMode.Reverse), label = "s")
    } else null
    Box(Modifier.offset(x, y).size(size)
        .graphicsLayer { val s = shift?.value ?: 0f; translationX = s * 40.dp.toPx(); translationY = s * 28.dp.toPx() }
        .background(Brush.radialGradient(listOf(color.copy(alpha = 0.5f), Color.Transparent))))
}

/** Slowly drifting colour glows that follow the current song. Sampled by the Prismal glass controls. */
@Composable
fun AmbientBackground(vm: MusicVM, modifier: Modifier = Modifier) {
    val pal = listOf(Color(0xFFFA2D48), Color(0xFF7B3FE4), Color(0xFF2F80ED), Color(0xFFFA7333), Color(0xFF33BF8C))
    val seed = Math.abs((vm.current?.id ?: "x").hashCode())
    val c1 by animateColorAsState(pal[seed % pal.size], tween(1400), label = "c1")
    val c2 by animateColorAsState(pal[(seed + 2) % pal.size], tween(1400), label = "c2")
    Box(modifier.background(Brush.verticalGradient(listOf(Color(0xFF1A0A14), Color(0xFF0B0B10), Color(0xFF0B0B10))))) {
        Blob(c1, 420.dp, (-120).dp, (-60).dp, vm.ambient, 9000)
        Blob(c2, 380.dp, 120.dp, 260.dp, vm.ambient, 11000)
        Blob(c1, 320.dp, (-80).dp, 520.dp, vm.ambient, 13000)
    }
}

@Composable
fun SettingsScreen(vm: MusicVM, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    val pb = LocalPrismal.current
    val speeds = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)
    val label = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    Box(Modifier.fillMaxSize().background(Color(0xFF0B0B10).copy(alpha = 0.9f))) {
        LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = 220.dp)) {
            item {
                Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 20.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Settings", fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    IconButton(onClose) { Icon(Icons.Filled.Close, "Close") }
                }
            }
            if (pb != null) {
                item {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Animated background", fontSize = 17.sp, modifier = Modifier.weight(1f))
                        PrismalGlassToggle(selected = { vm.ambient }, onSelect = { vm.toggleAmbient(it) }, backdrop = pb)
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Show Recently Played", fontSize = 17.sp, modifier = Modifier.weight(1f))
                        PrismalGlassToggle(selected = { vm.showRecent }, onSelect = { vm.toggleShowRecent(it) }, backdrop = pb)
                    }
                }
                item { Text("Sleep timer", fontSize = 17.sp, modifier = Modifier.padding(start = 20.dp, top = 22.dp, bottom = 10.dp)) }
                item {
                    PrismalRulerSelector(
                        value = vm.sleepMinutes, onValueChange = { vm.setSleep(it) }, valueRange = 0..120, backdrop = pb,
                        step = 5, majorTickEvery = 3, valueLabel = { if (it == 0) "Off" else "$it min" },
                        textStyle = label, textColor = Color.White, modifier = Modifier.fillMaxWidth()
                    )
                }
                item { Text("Playback speed", fontSize = 17.sp, modifier = Modifier.padding(start = 20.dp, top = 22.dp, bottom = 10.dp)) }
                item {
                    PrismalHorizontalSelector(
                        labels = speeds.map { if (it == 1f) "1x" else "${it}x" },
                        selectedIndex = speeds.indexOf(vm.speed).coerceAtLeast(0),
                        onSelected = { vm.changeSpeed(speeds[it]) },
                        backdrop = pb, textStyle = label, textColor = Color.White, modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

/** Search field with the iOS-style "Cancel" slide-in and focus squish (after the PrismalAGSL demo, MIT). */
@Composable
fun GlassSearchField(
    query: String,
    onQueryChange: (String) -> Unit,
    placeholder: String,
    onSearch: () -> Unit,
    onClear: () -> Unit
) {
    val pb = LocalPrismal.current ?: return
    var focused by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    val active = focused || query.isNotEmpty()
    val spec = spring<Float>(dampingRatio = 0.84f, stiffness = 420f)
    val cancelSpace by animateDpAsState(if (active) 66.dp else 0.dp, spring(dampingRatio = 0.84f, stiffness = 420f), label = "cancelSpace")
    val cancelAlpha by animateFloatAsState(if (active) 1f else 0f, spec, label = "cancelAlpha")
    val scale by animateFloatAsState(if (active) 0.985f else 1f, spec, label = "fieldScale")
    BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
        val fieldWidth = maxWidth - cancelSpace
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            PrismalGlassSurface(
                backdrop = pb,
                shape = { PrismalCapsule() },
                modifier = Modifier.width(fieldWidth).height(48.dp).graphicsLayer { scaleX = scale; scaleY = scale }
            ) {
                Row(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.Search, null, Modifier.size(18.dp), tint = Color.White.copy(0.7f))
                    BasicTextField(
                        value = query, onValueChange = onQueryChange,
                        modifier = Modifier.weight(1f).onFocusChanged { focused = it.isFocused },
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 17.sp),
                        cursorBrush = SolidColor(Accent),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { onSearch(); focusManager.clearFocus() }),
                        decorationBox = { inner ->
                            if (query.isEmpty()) Text(placeholder, color = Color.White.copy(0.55f), fontSize = 17.sp, maxLines = 1)
                            inner()
                        }
                    )
                    if (query.isNotEmpty()) {
                        Icon(Icons.Filled.Close, "Clear", Modifier.size(18.dp).clickable { onClear() }, tint = Color.White.copy(0.7f))
                    }
                }
            }
            Box(Modifier.width(cancelSpace).graphicsLayer { alpha = cancelAlpha }, contentAlignment = Alignment.CenterEnd) {
                Text("Cancel", color = Accent, maxLines = 1, softWrap = false, overflow = TextOverflow.Clip,
                    modifier = Modifier.width(56.dp).clickable(enabled = active) { onClear(); focusManager.clearFocus() })
            }
        }
    }
}

fun fmt(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return "%d:%02d".format(s / 60, s % 60) }
